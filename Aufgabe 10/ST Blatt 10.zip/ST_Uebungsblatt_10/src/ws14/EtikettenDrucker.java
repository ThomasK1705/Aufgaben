package ws14;

public interface EtikettenDrucker {

	/**
	 * Spezifikation siehe Aufgabenblatt
	 */
	void druckeEtikett(Farbe farbe, boolean qrCodeDrucken, int breite);

}
