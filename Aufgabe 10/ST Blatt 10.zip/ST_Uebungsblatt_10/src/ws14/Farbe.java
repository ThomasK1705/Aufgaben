package ws14;

public enum Farbe {
	
	WEISS,
	ROT,
	GELB,
	GRÜN,
	BLAU,
	LILA,
	BRAUN,
	SCHWARZ;

}
