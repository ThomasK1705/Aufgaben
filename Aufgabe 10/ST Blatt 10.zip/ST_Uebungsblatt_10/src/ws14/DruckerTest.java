package ws14;
import org.junit.Test;

public class DruckerTest {
	
	DruckerTestBewerter d1 = new DruckerTestBewerter();
	@Test
	public void testGueltig(){
		d1.druckeEtikett(Farbe.ROT, true, 7);
		d1.druckeEtikett(Farbe.GRÜN, false, 30);
		d1.druckeEtikett(Farbe.BLAU, true, 7);
	}
	
	
	@Test(expected=IllegalArgumentException.class)
	public void testSchwarz(){
		d1.druckeEtikett(Farbe.SCHWARZ, true, 7);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void test6(){
		d1.druckeEtikett(Farbe.ROT, false, 6);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void test31(){
		d1.druckeEtikett(Farbe.GRÜN, false, 31);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testMinus1(){
		d1.druckeEtikett(Farbe.BLAU, true, -1);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testNULL(){
		d1.druckeEtikett(null, true, 30);
	}
}
